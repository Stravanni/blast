package Blast_MetaBlocking;

public enum WeightingScheme {
    ARCS,
    ARCS_ENTRO,
    CBS,
    CBS_ENTRO,
    ECBS,
    ECBS_ENTRO,
    JS,
    JS_ENTRO,
    EJS,
    MI_ENTRO,
    EJS_ENTRO,
    CHI,
    CHI_ENTRO,
    FISHER_ENTRO
}
