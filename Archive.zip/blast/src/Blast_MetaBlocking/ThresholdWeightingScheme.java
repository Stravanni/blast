package Blast_MetaBlocking;

/**
 * @author stravanni
 */

public enum ThresholdWeightingScheme {
    AVG,
    AM2,
    AM3,
    AVG_MIN_MAX
}
